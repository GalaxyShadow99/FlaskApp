﻿class Graphe:
    """classe Graphe à l'aide d'un dictionnaire d'adjacence"""

    def __init__(self):
        """ constructeur de la classe """
        # création du dictionnaire vide
        self.adj ={}


    def ajouter_sommet(self,s):
        """ s est de type str
        cette méthode ajoute s au dictionnaire et crée un ensemble
        vide pour les voisins de ce nouveau sommet """
        if s not in self.adj:
            self.adj[s]=set()

    def ajouter_arc(self,s1,s2):
        self.ajouter_sommet(s1)
        self.ajouter_sommet(s2)
        self.adj[s1].add(s2)


    def arc(self,s1,s2):
        """ renvoie True si l'arc existe et False sinon """
        return s2 in self.adj[s1]

    def sommets(self):
        """ retourne la liste des sommets du graphe """
        return list(self.adj)

    def voisins(self,s):
        """ retourne l'ensemble des sommets voisins du sommet s """
        return self.adj[s]

    def affiche(self):
        for element in self.adj.keys() :
            print("sommet : ",element,"  avec pour voisins : ",self.adj[element])

#############  parcours en profondeur   ##############

def parcours_p(g,vus,s):
    """ parcours en profondeur depuis le sommet s """
    if s not in vus :
        vus.add(s)
        for v in g.voisins(s) :
            parcours_p(g,vus,v)

def existe_chemin(g,u,v):
    """ existe-t-il un chemin de u à v ? """
    vus=set()
    parcours_p(g,vus,u)
    return v in vus

#############  parcours en largeur   ##############

def parcours_l(g,source):
    """ parcours en largeur depuis le sommet source """
    dist={source:0}  # dist est un dictionnaire avec une clé source dont la valeur est 0
    courant={source}  # courant est un ensemble qui contient un seul élément : source
    suivant=set() # suivant est un ensemble vide
    while len(courant)>0 :
        s=courant.pop()
        for v in g.voisins(s) :
            if v not in dist :
                suivant.add(v)
                dist[v]=dist[s]+1
        if len(courant)==0 :
            courant=suivant
            suivant=set()
    return dist

def distance(g,u,v):
    """ distance de u à v et None si pas de chemin"""
    dist=parcours_l(g,u)
    if v in dist :
        return dist[v]
    else : return None

############  programme principal    ###########

g=Graphe()
g.ajouter_arc("A","B")
g.ajouter_arc("A","C")
g.ajouter_arc("A","D")

g.ajouter_arc("B","A")
g.ajouter_arc("B","D")

g.ajouter_arc("C","A")
g.ajouter_arc("C","D")
g.ajouter_arc("C","E")

g.ajouter_arc("D","A")
g.ajouter_arc("D","B")
g.ajouter_arc("D","C")
g.ajouter_arc("D","E")
g.ajouter_arc("D","F")

g.ajouter_arc("E","C")
g.ajouter_arc("E","D")
g.ajouter_arc("E","F")

g.ajouter_arc("F","E")
g.ajouter_arc("F","D")



g.affiche()

print ("Liste des sommets du graphe : ",g.sommets())




