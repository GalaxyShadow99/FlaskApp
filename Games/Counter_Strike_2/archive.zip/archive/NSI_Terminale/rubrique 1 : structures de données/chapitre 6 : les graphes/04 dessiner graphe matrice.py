﻿from turtle import *

class Graphe:
    """classe Graphe à l'aide d'une matrice d'adjacence"""

    def __init__(self,n):
        """ constructeur de la classe """
        # n est le nombre de sommets du graphe
        self.n =n
        # créer un tableau pour créer la matrice d'adjacence
        self.adj =[[False]*n for element in range(n)]

    def ajouter_arc(self,s1,s2):
        """ affecte True dans la case correspondant à l'arc entre s1 et s2 """
        self.adj[s1][s2]= True

    def arc(self,s1,s2):
        """ retourne True s'il existe un arc entre s1 et s2 """
        return self.adj[s1][s2]

    def voisins(self,s):
        """ retourne la liste des sommets voisins de s """
        v= []
        for i in range(self.n):
            if self.adj[s][i]:
                v.append(i)
        return v

    # à refaire avec des format f
    def affiche(self):
        print("  ",end="")
        for i in range(self.n) :
            print(i,end="  ")
        print()
        print()
        for i in range(self.n):
            print(i,"  ",end="")
            for j in range (self.n):
                if self.adj[i][j] : print("1 ",end=" ")
                else : print("0 ",end=" ")
            print()


    # avec les format
    def affichef(self):
        print(" La matrice d'adjacences :")
        print()
        print("{:^5}".format(""),end="")
        print("{:^5}".format(""),end="")
        for i in range(self.n) :
            print("{:^5}".format(i),end="")
        print()
        print("{:^5}".format(""),end="")
        print("{:^5}".format("|"),end="")
        for i in range(self.n) :
            print("{:^5}".format("---"),end="")
        print()

        for i in range(self.n):
            print("{:^5}".format(i),end="")
            print("{:^5}".format("|"),end="")
            for j in range (self.n):
                if self.adj[i][j] : print("{:^5}".format("1"),end="")
                else : print("{:^5}".format("0"),end="")
            print()
        print()


    # méthode de classe pour créer les positions des n sommets
    def positions_sommets():
        """ permet de déterminer 16 positions pour des sommets de graphe"""
        from random import shuffle
        # hauteur : hauteureur en pixel du rectangle dans lequel se fera le graphe
        # largeur : hauteureur en pixel du rectangle dans lequel se fera le graphe
        hauteur = 550
        largeur = 950
        # liste des coordonnées des 16 points dans un carré dont le côté a une longueur 1
        coord_0=[(-0.40,0.40),(-0.05,0.40),(0.15,0.35),(0.10,0.25),(0.40,0.30),(-0.25,0.15),(0.32,0.08),(-0.30,0),(0.20,0),(0.32,-0.08),(-0.25,-0.20),(0.08,-0.25),(0.38,-0.25),(0.15,-0.35),(-0.40,-0.40),(-0.05,-0.40)]
        # pour adapter les coordonnées au rectangle de la fenêtre turtle
        coord_1=[]
        for element in coord_0 :
            el=[]
            el.append(element[0]*largeur)
            el.append(element[1]*hauteur)
            coord_1.append(el)
        shuffle(coord_1)
        return coord_1


    def dessiner_graphe(self):
        assert self.n<=16,("il y a trop de sommets pour appliquer cette méthode")
        # pour définir la taille du rectangle dans lequel se fera le graphe
        setup(950,550)
        up()
        speed(0)
        coord=Graphe.positions_sommets()
        hideturtle()

        # dessiner les arcs en premier
        for i in range(self.n):
            for j in range (self.n):
                if self.adj[i][j] :
                    up()
                    depart=coord[i]
                    arrivee=coord[j]
                    goto(depart[0],depart[1]+10)
                    down()
                    goto(arrivee[0],arrivee[1]+10)
                    up()
                else : pass

        # dessiner ensuite les sommets et les clés
        for i in range (self.n) :
            position =coord[i]
            x,y=position[0],position[1]
            goto(x,y)
            down()
            color("black","yellow")
            begin_fill()
            circle(20)
            end_fill()
            up()
            goto(x-5,y+10)
            down()
            write(i,font=("arial",16,"normal"))
            up()
        done()




############  programme principal    ###########

g=Graphe(4)
g.ajouter_arc(0,1)
g.ajouter_arc(0,3)
g.ajouter_arc(1,2)
g.ajouter_arc(3,1)

"""
g.affichef()

print(g.voisins(0))
"""

g.dessiner_graphe()




