﻿from module_graphe_matrice import *

class Graphe:
    """classe Graphe à l'aide d'une matrice d'adjacence"""

    def __init__(self,n):
        """ constructeur de la classe """
        # n est le nombre de sommets du graphe
        self.n =n
        # créer un tableau pour créer la matrice d'adjacence
        self.adj =[[False]*n for element in range(n)]

    def ajouter_arc(self,s1,s2):
        """ affecte True dans la case correspondant à l'arc entre s1 et s2 """
        self.adj[s1][s2]= True

    def arc(self,s1,s2):
        """ retourne True s'il existe un arc entre s1 et s2 """
        return self.adj[s1][s2]

    def voisins(self,s):
        """ retourne la liste des sommets voisins de s """
        v= []
        for i in range(self.n):
            if self.adj[s][i]:
                v.append(i)
        return v

    # à refaire avec des format f
    def affiche(self):
        print("  ",end="")
        for i in range(self.n) :
            print(i,end="  ")
        print()
        print()
        for i in range(self.n):
            print(i,"  ",end="")
            for j in range (self.n):
                if self.adj[i][j] : print("1 ",end=" ")
                else : print("0 ",end=" ")
            print()


    # avec les format
    def affichef(self):
        print(" La matrice d'adjacences :")
        print()
        print("{:^5}".format(""),end="")
        print("{:^5}".format(""),end="")
        for i in range(self.n) :
            print("{:^5}".format(i),end="")
        print()
        print("{:^5}".format(""),end="")
        print("{:^5}".format("|"),end="")
        for i in range(self.n) :
            print("{:^5}".format("---"),end="")
        print()

        for i in range(self.n):
            print("{:^5}".format(i),end="")
            print("{:^5}".format("|"),end="")
            for j in range (self.n):
                if self.adj[i][j] : print("{:^5}".format("1"),end="")
                else : print("{:^5}".format("0"),end="")
            print()
        print()

############  programme principal    ###########

g=Graphe(4)
g.ajouter_arc(0,1)
g.ajouter_arc(0,3)
g.ajouter_arc(1,2)
g.ajouter_arc(3,1)

g.affichef()


print(g.voisins(0))

print(g.arc(1,3))

dessiner_graphe(g)



