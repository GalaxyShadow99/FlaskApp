﻿class File:
    """ classe File """

    def __init__(self):
        """ constructeur de la classe """
        self.file = []

    def enfiler(self, e):
        """ enfile l'élément e en queue de la file """
        self.file.append(e)

    def defile(self):
        """ défile l'élément de tête de la file et le retourne """
        s = self.file.pop(0)
        return s

    def estVide(self):
        """ test si la file est vide ( retourne VRAI) ou non ( retourne FAUX )"""
        return len(self.file) == 0

    def __str__(self):
        retour = ""
        for e in self.file:
            retour += str(e) + ','
        return retour


class Sommet:
    """classe Sommet"""

    def __init__(self,nom):
        """ constructeur de la classe """
        self.nom =nom
        self.couleur="Blanc"

    def __str__(self):
        return str(self.nom)


class Graphe:
    """classe Graphe à l'aide des listes d'adjacences"""

    def __init__(self):
        """ constructeur de la classe """
        # créer un tableau pour contenir la liste des sommets
        self.ListeS =[]
        # créer un dictionnaire où chaque clé correspond au nom du sommet et sa valeur
        # à la liste d'adjacence de ce sommet. Cette liste d'adjacence contiendra les sommets
        self.ListeAdj ={}

    def ajouter_sommet(self,s):
        """ ajoute s à la liste des sommets et prépare la liste d'adjacences vide pour ce sommet """
        self.ListeS.append(s)
        self.ListeAdj[s.nom] =[]

    def ajouter_arc(self,s1,s2):
        """ajoute ces deux sommets dans self.ListeS et crée les listes d'adjacences correspondantes
        ajoute s2 à la liste d'adjacences du sommet nom1 """

        if s1 in self.ListeS :
            pass
        else :
            self.ListeS.append(s1)
            self.ListeAdj[s1.nom] =[]

        if s2 in self.ListeS :
            pass
        else :
            self.ListeS.append(s2)
            self.ListeAdj[s2.nom] =[]

        self.ListeAdj[s1.nom].append(s2)


    def get_sommet(self,nom1):
        """ retourne le sommet de nom nom1 """
        for i in range(len(self.listeS)):
            if self.ListeS[i].nom == nom1 :
                return self.ListeS[i]

    def reset_couleur(self):
        """ réinitialise tous les sommets du graphe à la couleur blanche """
        for element in self.ListeS :
            element.couleur="Blanc"

    def affiche_adj(self):
        for nom,adj in self.ListeAdj.items() :
            print("Sommet : ", nom,end="")
            print(" Liste d'adjacence : ",end="")
            for i in adj : print(i,end="")
            print()

    def affiche_couleur(self):
        for s in self.ListeS :
            print("Sommet : ", s.nom,end="")
            print(" Couleur : ",s.couleur,end="")
            print()

#############    parcours en profondeur   #####################

def parcours_p(g,s):
    if s.couleur=="Blanc" :
        s.couleur="Noir"
        for v in g.ListeAdj[s.nom]:
            parcours_p(g,v)

def chemin(g,s1,s2):
    parcours_p(g,s1)
    chemin_bool=False
    for element in g.ListeS :
        if (element.nom,element.couleur) == (s2.nom,"Noir"):
            chemin_bool=True
    return chemin_bool



#############    parcours en largeur   #####################

def parcours_l(g,source):
    """ parcours en largeur depuis le sommet source """
    dist={source:0}  # dist est un dictionnaire avec une clé source dont la valeur est 0
    courant=[source]  # courant est un tableau qui contient un seul élément : source
    suivant=[] # suivant est un tableau vide
    while len(courant)>0 :
        s=courant.pop()
        for v in g.ListeAdj[s.nom] :
            if v.couleur == "Blanc" :
                v.couleur="Noir"
                suivant.append(v)
                dist[v]=dist[s]+1
        if len(courant)==0 :
            courant=suivant
            suivant=[]
    return dist

def distance(g,u,v):
    """ distance de u à v et None si pas de chemin"""
    if u==v : return 0
    dist=parcours_l(g,u)
    if v in dist.keys() :
        return dist[v]
    else : return None





############  programme principal  #########################


s1=Sommet("1")
s2=Sommet("2")
s3=Sommet("3")
s4=Sommet("4")
s5=Sommet("5")
s6=Sommet("6")
s7=Sommet("7")

g=Graphe()

g.ajouter_sommet(s7)

#liste d'adjacences du sommet 1
g.ajouter_arc(s1,s2)
g.ajouter_arc(s1,s3)

#liste d'adjacences du sommet 2
g.ajouter_arc(s2,s1)
g.ajouter_arc(s2,s3)
g.ajouter_arc(s2,s6)

#liste d'adjacences du sommet 3
g.ajouter_arc(s3,s1)
g.ajouter_arc(s3,s2)
g.ajouter_arc(s3,s4)
g.ajouter_arc(s3,s6)

#liste d'adjacences du sommet 4
g.ajouter_arc(s4,s3)
g.ajouter_arc(s4,s5)

#liste d'adjacences du sommet 5
g.ajouter_arc(s5,s4)
g.ajouter_arc(s5,s6)

#liste d'adjacences du sommet 6
g.ajouter_arc(s6,s2)
g.ajouter_arc(s6,s3)
g.ajouter_arc(s6,s5)



"""
#print(g.ListeAdj[s1.nom])

g.affiche_adj()
print("couleurs initiales")
g.affiche_couleur()

parcours_p(g,s1)
print("couleurs après parcours en partant de ")
g.affiche_couleur()

print(chemin(g,s1,s5))

g.reset_couleur()
print("couleurs après reset_couleur ")
g.affiche_couleur()

"""
u=s1
v=s1
print("distance entre ",str(u.nom)," et ",str(v.nom)," : ",distance(g,u,v))


