﻿import networkx as nx
import matplotlib.pyplot as plt


g1 = nx.Graph()

g1.add_node(1)
g1.add_node(2)
g1.add_node(3)
g1.add_node(4)
g1.add_node(5)
g1.add_node("autre")

g1.add_edge(1,2)

############  remarque   ############################
# g1.add_edge(2,1)
# inutile après  g1.add_edge(1,2)   puisque le graphe n'est pas orienté
############  fin remarque   ########################

g1.add_edge(1,3)
g1.add_edge(1,4)
g1.add_edge(2,3)
g1.add_edge(2,4)
g1.add_edge(2,4)

"""
la fonction draw de matplotlib permet d'afficher le graphe g1

with_labels : avec ou sans les étiquettes des sommets
font_weight :
node_size : taille du cercle qui représente un sommet
node_color : couleur du fond du sommet

lors de l'affichage, la position des sommets semble aléatoire.
"""

#nx.draw(g1, with_labels=True, font_weight='bold', node_size=800, node_color='yellow')




"""
La méthode number_of_nodes() retourne le nb de sommets du graphe
"""
#nb=g1.number_of_nodes()
#print (nb)



g2 = nx.DiGraph()
g2.add_node('a')
g2.add_node('b')
g2.add_node('c')
g2.add_node('d')
g2.add_edge('a','b')
g2.add_edge('b','a')
g2.add_edge('a','c')
g2.add_edge('d','a')

pos = nx.circular_layout(g2)
nx.draw(g2,pos, with_labels=True, font_weight='bold', node_size=800, node_color='lightgrey',edge_color='blue',arrowstyle='fancy',arrowsize=20)

print(g2.is_directed())


plt.show()

# pour convertir un grap en list
var=list(g1.nodes())
print(var)

# pour créer une liste des liens du graphe
var=list(g1.edges())
print(var)

# pour calculer le nombre de chemin

# nx.all_simple_paths(g1,3,4) est un objet de la class generator
#ce sot des objets itérable, donc pour les imprimer, il faut utiliser la méthode next(),
# qui commence avec le premier élément et qui s'incrémente ensuite

nb=nx.all_simple_paths(g1,3,4)

# pourquoi dans un cas cela ne donne pas la même chose que dans l'autre cas ?
"""
for i in nb:
    print(next(nb))
"""
for element in nb:
    print(element)





















