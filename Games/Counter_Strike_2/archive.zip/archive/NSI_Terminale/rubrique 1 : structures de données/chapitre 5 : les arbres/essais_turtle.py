﻿from turtle import *
up()
goto(-100,0)
down()
x,y=pos()
print(x,y)
right(45)
forward(100)
write("A",font=("arial",12,"normal"))
#textinput("blablabla","que faut-il saisir ?")
#circle(100)
done()

