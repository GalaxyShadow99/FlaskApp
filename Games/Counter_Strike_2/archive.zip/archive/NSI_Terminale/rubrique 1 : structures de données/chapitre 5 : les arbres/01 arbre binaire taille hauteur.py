﻿class Noeud:
    """ un nœud d’un arbre binaire """

    def __init__(self,g,v,d):
        """ constructeur de la classe Noeud """
        self.gauche = g
        self.valeur = v
        self.droit = d


def taille(a):
    """ calcul le nombre de noeuds de l'arbre
    dont le noeud a est la racine"""
    if a==None :
        return 0
    else :
        return 1+taille(a.gauche)+taille(a.droit)


def hauteur(a):
    """ calcul la hauteur de l'arbre
    dont le noeud a est la racine"""
    if a==None :
        return 0
    else :
        return 1+max(hauteur(a.gauche),hauteur(a.droit))


def hauteur_bis(a):
    """ calcul la hauteur de l'arbre
    dont le noeud a est la racine"""
    if a==None :
        return 0
    else :
        x=hauteur_bis(a.droit)+1
        y=hauteur_bis(a.gauche)+1
        if y>x :
            return y
        else :
            return x




""" Construction d'un arbre à 3 noeuds avec le constructeur
 de la classe Noeud présentée de deux manières

### à partir des feuilles

gA=Noeud(None,'B',None)
dA=Noeud(None,'C',None)
a1=Noeud(gA,'A',dA)

### de manière récursive
### à remplir facilement avec des copier coller des lignes ci-dessus

a2=Noeud(Noeud(None,'B',None),'A',Noeud(None,'C',None))
"""


""" Construction d'un arbre à 4 noeuds avec le constructeur
 de la classe Noeud présentée de deux manières """

### à partir des feuilles

dB=Noeud(None,'C',None)
gA=Noeud(None,'B',dB)
dA=Noeud(None,'D',None)
a3=Noeud(gA,'A',dA)

### de manière récursive
### à remplir facilement avec des copier coller des lignes ci-dessus

a4=Noeud(Noeud(None,'B',Noeud(None,'C',None)),'A',Noeud(None,'D',None))



print(taille(a4))

print(hauteur(a4))
print(hauteur_bis(a4))


