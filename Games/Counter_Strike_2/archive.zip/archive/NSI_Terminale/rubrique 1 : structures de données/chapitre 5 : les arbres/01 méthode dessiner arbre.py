﻿
from turtle import *

class Noeud:
    """ un nœud d’un arbre binaire """

    def __init__(self,g,v,d):
        """ constructeur de la classe Noeud """
        self.gauche = g
        self.valeur = v
        self.droit = d

    # méthode de classe
    def fct_taille(a):
        """ retourne le nombre de noeuds de l'arbre
        dont le noeud a est la racine"""
        if a==None :
            return 0
        else :
            return 1+Noeud.fct_taille(a.gauche)+Noeud.fct_taille(a.droit)

    # méthode pour calculer la taille qui utilise la fonction récursive fct_taille
    def meth_taille(self):
        """ méthode qui retourne le nombre de noeuds de l'arbre sur
        lequel s'applique la méthode """
        return Noeud.fct_taille(self)

    # méthode de classe
    def fct_hauteur(a):
        """ retourne la hauteur de l'arbre
        dont le noeud a est la racine"""
        if a==None :
            return 0
        else :
            return 1+max(Noeud.fct_hauteur(a.gauche),Noeud.fct_hauteur(a.droit))

    # méthode pour calculer la taille qui utilise la fonction récursive fct_hauteur
    def meth_hauteur(self):
        """ méthode qui retourne le nombre de noeuds de l'arbre sur
        lequel s'applique la méthode """
        return Noeud.fct_hauteur(self)


    # méthode de classe
    def fct_affiche(arbre):
        """ question 3 """
        if arbre is None:
            sortie = ""
        else:
            sortie="("
            sortie = sortie + str(Noeud.fct_affiche(arbre.gauche))
            sortie = sortie + str(arbre.valeur)
            sortie = sortie + str(Noeud.fct_affiche(arbre.droit))
            sortie = sortie + ")"
        return sortie

    # méthode pour afficher un arbre qui utilise la fonction récursive fct_affiche
    def meth_affiche(self):
        """ méthode qui affiche l'arbre sur
        lequel s'applique la méthode """
        print(Noeud.fct_affiche(self))

    """
    # méthode pour tester l'égalité entre deux arbres
    def __eq__(self, autre):
        # question 4
        return Noeud.fct_affiche(self)==Noeud.fct_affiche(autre)
    """

    # méthode pour tester l'égalité entre deux arbres
    def egalite(self, autre):
        """question 4 """
        return Noeud.fct_affiche(self)==Noeud.fct_affiche(autre)


    def __eq__(self, autre):        # version 2 du __eq__
        """question 4"""
        if autre is None and self is None:
            return True
        elif autre is None or self is None:
            return False
        else:
            return self.gauche==autre.gauche and self.valeur==autre.valeur and self.droit==autre.droit



##### fonction pour dessiner un arbre   ########



def dessiner(a,x,y,longueur,angle):

    if a is None:
        pass
    else:
        x,y=pos()
        color("black","yellow")
        begin_fill()
        circle(20)
        end_fill()
        up()
        goto(x-5,y+10)
        down()
        write(a.valeur,font=("arial",14,"normal"))
        up()
        goto(x,y)
        down()
        right(angle)
        forward(longueur)
        left(angle)
        xd,yd=pos()
        dessiner(a.droit,xd,yd,longueur*0.6,angle+10)
        up()
        goto(x,y)
        down()
        right(180-angle)
        forward(longueur)
        left(180-angle)
        xg,yg=pos()
        dessiner(a.gauche,xg,yg,longueur*0.6,angle+10)






######  programme principal    #################

########  création arbre    ###################



gA=Noeud(None,'B',None)
dA=Noeud(None,'C',None)
a2=Noeud(gA,'A',dA)

dB=Noeud(None,'C',None)
gA=Noeud(None,'B',dB)
gD=Noeud(None,'E',None)
dA=Noeud(gD,'D',None)
a3=Noeud(gA,'A',dA)


a4=Noeud(Noeud(None,'B',Noeud(None,'C',None)),'A',Noeud(None,'D',None))


a5=Noeud(Noeud(None,'B',Noeud(None,'C',None)),'A',Noeud(None,'E',None))


########  dessin de l'arbre    ###################
print("dessin de l'arbre :")

up()
goto(0,100)
down()

dessiner(a3,0,100,150,30)
done()

##########   affichage de l'arbre   #################

print("affiche avec la fonction qui a print à la fin")
a3.meth_affiche()








"""
print(taille(a4))

print(hauteur(a4))
"""

"""
print("arbre")
a3.meth_affiche()

print("taille")
print(a3. meth_taille())

print("hauteur")
print(a3. meth_hauteur())

print("test égalité")
print(a3.egalite(a5))
print(" test avec eq")
print(a3==a4)
"""

