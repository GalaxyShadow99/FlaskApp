﻿######  question 1 #################

"""
# dictionnaire français anglais
dico_fran_angl={"bonjour":"hello","pomme":"apple","voiture":"car","liberté":"freedom","fille":"girl","garçon":"boy"}

# dictionnaire anglais français
dico_angl_fran={"hello":"bonjour","apple":"pomme","car":"voiture","freedom":"liberté","girl":"fille","boy":"garçon"}

def traduction_français_anglais(dico_fran_angl,mot):
    if mot not in dico_fran_angl :
        print("Le mot que vous souhaitez traduire n'est pas dans la dernière édition de notre dictionnaire")
    else :
        print ("La traduction du mot ", mot, " en anglais est : ",dico_fran_angl[mot] )

traduction_français_anglais(dico_fran_angl,"pomme")


######  question 2 #################

liste=["bonjour","hello","pomme","apple","voiture","car","liberté","freedom","fille","girl","garçon","boy"]

def list_to_dico(liste):
    n=len(liste)
    if n%2 !=0 :
        print(" il y a un problème sur le nombre d'éléments de la liste")
        return None
    else :
        dico={}
        for i in range(0,n,2):
            dico[liste[i]]=liste[i+1]
        return dico

print(list_to_dico(liste))


"""
######  question 4 #################

def histogramme(s):
    d = dict()
    for c in s:
        if c not in d:
            d[c] = 1
        else:
            d[c]=d[c]+1
    return d

texte="""Ah ! non ! c’est un peu court, jeune homme !
On pouvait dire… Oh ! Dieu ! … bien des choses en somme…
En variant le ton, – par exemple, tenez :
Agressif : « Moi, monsieur, si j’avais un tel nez,
Il faudrait sur-le-champ que je me l’amputasse ! »
Amical : « Mais il doit tremper dans votre tasse
Pour boire, faites-vous fabriquer un hanap ! »
Descriptif : « C’est un roc ! … c’est un pic ! … c’est un cap !
Que dis-je, c’est un cap ? … C’est une péninsule !"""

print(histogramme(texte))





