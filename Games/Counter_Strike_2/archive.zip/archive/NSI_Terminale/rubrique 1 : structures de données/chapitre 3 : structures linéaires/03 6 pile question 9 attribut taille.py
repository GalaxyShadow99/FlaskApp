﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None
        self.taille = 0

    def est_vide(self) :
        return self.pile  is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)
        self.taille=self.taille +1

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        self.taille=self.taille -1
        return val

    def consulter(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.pile.valeur

    def vider(self) :
        self.pile=None
        self.taille = 0

    def longueur(self) :
        return self.taille


    def __str__(self):
        retour="vide"
        if self.pile ==None :
            return retour
        else :
            retour=""
            c=self.pile
            while c.suivante != None :
                retour = retour +str(c.valeur) +" -> "
                c=c.suivante
            retour = retour+str(c.valeur)
        return retour


pi=Pile2()
print("voici la pile pi : ", pi)


p=Pile2()
p.empiler(1)
p.empiler(2)
p.empiler(3)
p.empiler(4)
nb=p.consulter()
print(nb)
p.empiler(5)
p.empiler(6)
#p.vider()

nb=p.longueur()
print("taille de la pile:",nb)

print("voici la pile  : ", p)
