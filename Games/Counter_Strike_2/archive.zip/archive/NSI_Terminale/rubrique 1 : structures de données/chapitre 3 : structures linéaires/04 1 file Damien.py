﻿####################################################################
##                définitiOn des classes
####################################################################

class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class File2 :
    """ une file construite avec une liste chaînée"""

    def __init__(self):
        self.premier=None
        self.dernier=None

    def est_vide(self) :
        return self.premier is None



    ################################################
    ##     Damien et sa méthode "enfiler"
    ################################################


    # méthode statique
    # méthode de classe

    def recur_add(v,c):
        if c.suivante==None :
            return Cellule(c.valeur,Cellule(v,None))
        else :
            return Cellule(c.valeur,File2.recur_add(v,c.suivante))


    def enfiler(self,val) :

        if self.est_vide():
            self.premier=Cellule(val,None)
            self.dernier=Cellule(val, None)

        elif self.premier.suivante is None:
            self.premier=Cellule(self.premier.valeur,Cellule(val, None))
            self.dernier=Cellule(val, None)

        else :
            self.dernier=Cellule(val, None)
            self.premier=File2.recur_add(val,self.premier)








    def ajouter(self,val) :
        c=Cellule(val, None)
        if self.est_vide():
            self.premier=c
        else :
            self.dernier.suivante=c
        self.dernier=c

    def retirer(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.premier.valeur
        self.premier=self.premier.suivante
        if self.premier==None :
            self.dernier=None
        return val

    def compter(self):
        n=0
        c=self.premier
        while c is not None :
            n=n+1
            c=c.suivante
        return n

    def consulter_premier(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.premier.valeur

    def vider(self) :
        self.premier=None
        self.dernier=None

    def __str__(self):
        retour =""
        if self.premier == None :
            return retour
        c=self.premier
        while not (c.suivante==None):
            e =c.valeur
            retour = retour + str(e) + ','
            c=c.suivante
        e=c.valeur
        retour=retour+str(e)
        return retour


####################################################################
##
##                 programme principal
##
####################################################################

f_damien=File2()

f_damien.enfiler(1)
f_damien.enfiler(2)
f_damien.enfiler(3)
f_damien.enfiler(4)
f_damien.enfiler(5)
f_damien.enfiler(6)

print("La file est la suivante :",f_damien)

val = f_damien.consulter_premier()
print("Le premier élément de la file a pour valeur : ",val)

nb=f_damien.compter()
print("La file contient ",nb, " éléments ")


"""

##############################
f=File2()
f.ajouter(1)
f.ajouter(2)
f.ajouter(3)
f.ajouter(4)
f.ajouter(5)
f.ajouter(6)
f.retirer()
f.retirer()
################################


print("La file est la suivante :",f)

val = f.consulter_premier()
print("Le premier élément de la file a pour valeur : ",val)

nb=f.compter()
print("La file contient ",nb, " éléments ")

"""



