﻿class File:
    def __init__(self):
        self.file = []

    def ajouter(self, e):
        self.file.append(e)

    def tete(self):
        return self.file[0]

    def prelever(self):
        s = self.file.pop(0)
        return s

    def estVide(self):
        return len(self.file) == 0

    def __str__(self):
        retour = ""
        for e in self.file:
            retour += str(e) + ','
        return retour

f=File()
f.ajouter(0)
f.ajouter(1)
f.ajouter(2)
f.ajouter(3)
f.prelever()
f.prelever()
if f.estVide():
    print('La file est vide')
else:
    print("La file n'est pas vide")
print('La file est la suivante : ',f)
