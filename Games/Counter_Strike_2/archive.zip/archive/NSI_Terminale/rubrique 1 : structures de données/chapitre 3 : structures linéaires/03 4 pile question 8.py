﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None

    def est_vide(self) :
        return self.pile  is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        return val

    def consulter(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.pile.valeur

    def vider(self) :
        self.pile=None

    def taille1(self) :
        return longueur(self.pile)

    def taille2(self) :
        long=0
        while self.pile!=None :
            long=long+1
            self.pile=self.pile.suivante
        return long

    # attention cette méthode d'affichage vide la pile !!!!!!
    def affiche_pile1(self):
        while self.pile!=None :
            print(self.pile.valeur)
            self.pile=self.pile.suivante
        print("=========")

    # il faut donc corriger ce problème  ...
    def affiche_pile2(self):
        temp=self.pile
        while temp!=None :
            print(temp.valeur)
            temp=temp.suivante
        print("=========")


def longueur(cellule):
    if cellule == None:return 0
    else : return (1+longueur(cellule.suivante))


################## programme principal   ################


p=Pile2()
p.empiler(1)
p.empiler(2)
p.empiler(3)
p.empiler(4)
p.empiler(5)
#p.vider()
p.affiche_pile2()

print(p.est_vide())

print(p.consulter())

nb=p.taille1()
print("La taille de la pile : ",nb)



