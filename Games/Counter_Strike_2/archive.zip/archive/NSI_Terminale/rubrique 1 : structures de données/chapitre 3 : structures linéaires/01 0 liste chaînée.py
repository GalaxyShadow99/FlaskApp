﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s


def creer_liste_vide() :
	return None

def test_liste_vide(lst) :
    if lst==None :
        return True
    else :
        return False

def ajoute_tete_liste (val,lst) :
    lst=Cellule(val,lst)
    return lst


def affiche_recur(lst):
    if lst==None:
        print("\n")
    else :
        print(lst.valeur," ",end="")
        affiche_recur(lst.suivante)

def affiche_while(lst):
    while lst != None :
        print(lst.valeur," ",end="")
        lst=lst.suivante


def compter_recur (lst) :
    if lst==None :
        return 0
    else :
        return 1+compter_recur(lst.suivante)

def compter_while (lst) :
    if lst==None :
        return 0
    nb=0
    while lst is not None :
        nb=nb+1
        lst=lst.suivante
    return nb

def nième_recur(n,lst):
    if lst==None :
        raise IndexError("Vous avez un problème avec l'indice n choisi")
    if n==0 :
        return lst.valeur
    else :
        return nième_recur(n-1,lst.suivante)

def nième_while(n,lst):
    i=0
    c=lst
    while i <n and c is not None :
        i=i+1
        c=c.suivante
    if n<0 or c is None:
        raise IndexError("indice invalide")
    return c.valeur



L=creer_liste_vide()
print(test_liste_vide(L))
L=ajoute_tete_liste (1,L)
L=ajoute_tete_liste (3,L)
L=ajoute_tete_liste (5,L)
L=ajoute_tete_liste (7,L)
L=ajoute_tete_liste (9,L)
print(test_liste_vide(L))

"""
nb=compter_recur(L)
print("longueur liste :",nb)

nb=compter_while(L)
print("longueur liste :",nb)

i=0
nb=nième_recur(i,L)
print("L'élément d'indice ",i," a pour valeur",nb)

nb=nième_while(i,L)
print("L'élément d'indice ",i," a pour valeur",nb)

"""

affiche_recur(L)

affiche_while(L)
