﻿class Pile :
    def __init__ (self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def taille(self):
        return len(self.pile)

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

def retourne_tableau(tab):
    p=Pile()
    for i in range(len(tab)):
        p.empiler(tab[i])
    #print(p)
    tab_temp=[]
    for i in range (len(tab)):
        tab_temp.append(p.depiler())
    return tab_temp




######### progamme principal #################

tab=[1,2,3,4,5,6,7]

print(tab)

print(retourne_tableau(tab))

