﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None

    def est_vide(self) :
        return self.pile  is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        return val

    def consulter(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.pile.valeur

    def vider(self) :
        self.pile=None

    def taille1(self):
        n=0
        c=self.pile
        while c is not None :
            n=n+1
            c=c.suivante
        return n

    """
    # Peut-on utiliser une récursivité avec une méthode de classe ?
    def taille2(self):
        if self.pile is None : return 0
        else : return 1 + self.pile.suivante.taille2()

    Et non !!!!!!!!!!!!!

    """


p=Pile2()
p.empiler(1)
p.empiler(2)
p.empiler(3)
p.empiler(4)
nb=p.consulter()
print(nb)
p.empiler(5)
p.empiler(6)
#p.vider()

nb=p.taille1()
print("taille de la pile:",nb)


