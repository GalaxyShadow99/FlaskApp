﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None
        self.taille = 0

    def est_vide(self) :
        return self.pile  is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)
        self.taille=self.taille +1

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        self.taille=self.taille -1
        return val

    def consulter(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.pile.valeur

    def vider(self) :
        self.pile=None

    def longueur(self) :
        return self.taille

def ouvrante_associée(s,f):
    pile=Pile2()
    for i in range (f) :
        if s[i]=="(":
            pile.empiler(i)
        elif s[i]==")":
            pile.depiler()
    return pile.consulter()

s1="(3+4)*(2-(4))"

s2="((3+4))+(3-1)*(2-(4))"

print(ouvrante_associée(s2,12))




