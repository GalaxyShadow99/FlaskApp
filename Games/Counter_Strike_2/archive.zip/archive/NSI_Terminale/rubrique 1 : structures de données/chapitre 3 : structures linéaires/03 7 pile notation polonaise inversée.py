﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None
        self.taille = 0

    def est_vide(self) :
        return self.pile  is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)
        self.taille=self.taille +1

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        self.taille=self.taille -1
        return val

    def consulter(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.pile.valeur

    def vider(self) :
        self.pile=None

    def longueur(self) :
        return self.taille

# avec une erreur classique !!!!!!! ( pour - et pour / )
def eval_polonaise_inverse1(s):
    pile=Pile2()
    for e in s.split(" "):
        if e=="+" or e=="-" or e=="*" or e=="/" :
            x=pile.depiler()
            y=pile.depiler()
            if e=="+": z=x+y
            if e=="-": z=x-y
            if e=="*": z=x*y
            if e=="/": z=x/y
            pile.empiler(z)
        else :
            pile.empiler(int(e))
    res=pile.depiler()
    assert pile.est_vide(), ("la chaine de caractère n'est pas correctement saisie")
    return res

def eval_polonaise_inverse(s):
    pile=Pile2()
    for e in s.split(" "):
        if e=="+" or e=="-" or e=="*" or e=="/" :
            x=pile.depiler()
            y=pile.depiler()
            if e=="+": z=y+x
            if e=="-": z=y-x
            if e=="*": z=y*x
            if e=="/": z=y/x
            pile.empiler(z)
        else :
            pile.empiler(int(e))
    res=pile.depiler()
    assert pile.est_vide(), ("la chaine de caractère n'est pas correctement saisie")
    return res



sa="4 5 * 6 +"
sb="4 2 + 5 6 + *"
sc="3 4 5 * + 6 -"
s1="1 2 3 * + 4"
sd="10 5 / 3 2 + 10 * +"

res=eval_polonaise_inverse2(sd)
print(res)

