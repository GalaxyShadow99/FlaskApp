# Créé par laure, le 14/11/2021 en Python 3.7
class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Pile2 :
    """ une pile construite avec une liste chaînée"""

    def __init__(self):
        self.pile=None

    def est_vide(self) :
        return self.pile is None

    def empiler(self,val) :
        self.pile=Cellule(val,self.pile)

    def depiler(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.pile.valeur
        self.pile=self.pile.suivante
        return val


    def taille1(self) :
        return Pile2.longueur(self.pile)

    @staticmethod
    def longueur(cellule):
        if cellule == None:return 0
        else : return (1+Pile2.longueur(cellule.suivante))


    def afficher(self):
        temp=self.pile
        while temp!=None :
            print(temp.valeur)
            temp=temp.suivante
        print("=========")

######################################################################################

def copier_pile(p):
    p_temp=Pile2()
    while not(p.est_vide()):
        a=p.depiler()
        p_temp.empiler(a)
    p_copy=Pile2()
    while not(p_temp.est_vide()):
        a=p_temp.depiler()
        p_copy.empiler(a)
    return p_copy


def copier_facile(p):
    p_copy=Pile2()
    p_copy.pile=p.pile
    return p_copy


######################################################################################
"""
Ecrire une fonction copier_pile qui prend en paramètre une pile p
et qui renvoie une autre pile contenant les mêmes éléments que p dans le même ordre.
"""
p1=Pile2()

for i in range(7):
 	p1.empiler(i)
print("Affichage de p1 : ")
p1.afficher()


print("Taille de la pile : ",p1.taille1())

"""
print("Affichage de p2 : ")
p2=copier_pile(p1)
p2.afficher()
"""

print("Affichage de p2 : ")
p2=copier_facile(p1)
p2.afficher()
