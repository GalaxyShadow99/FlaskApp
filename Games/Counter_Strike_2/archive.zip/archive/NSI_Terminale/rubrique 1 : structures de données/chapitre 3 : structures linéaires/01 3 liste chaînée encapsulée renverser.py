﻿############   définition des classes    ###############

class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Liste :
    """une liste chaînée"""

    def __init__(self):
        self.tete=None

    def est_vide(self) :
        return self.tete is None

    def ajoute(self,val) :
        self.tete=Cellule(val,self.tete)

    def affiche1(self):
        cel=self.tete
        while cel != None :
            print(cel.valeur," ",end="")
            cel=cel.suivante
        print()

    def compter(self) :
        if self.tete==None :
            return 0
        else :
            return 1+ Liste.longueur(self.tete.suivante)

    # méthode de classe utilisée pour la méthode compter(self) ci-dessus
    # ici on est obligé de créer une méthode de classe car le paramètre self
    # de compter est du type Liste alors que le paramètre cel de longueur
    # est du type Cellule

    def longueur(cel):
        if cel==None :
            return 0
        else :
            return 1 + Liste.longueur(cel.suivante)

    def nieme(self,n):
        if self.tete==None :
            raise IndexError("Il y a un problème avec la valeur n choisie")
        else :
            if n==1 :
                return self.tete.valeur
            else :
                return Liste.nième_recur(n-1,self.tete.suivante)


    # méthode de classe utilisée pour la méthode nieme(self) ci-dessus
    # pour les mêmes raisons que ci-dessus ici encore on est obligé de
    # créer une méthode de classe car le paramètre self de nieme
    # est du type Liste alors que le paramètre cel de nieme_recur
    # est du type Cellule

    def nième_recur(n,cel):
        if cel==None :
            raise IndexError("Vous avez un problème avec l'indice n choisi")
        if n==1 :
            return cel.valeur
        else :
            return Liste.nième_recur(n-1,cel.suivante)

    def renverser(self):
        """ renvoie une liste avec les éléments dans l'ordre
        Inverse des éléments de la liste sur laquelle s'applique
        la méthode"""

        lst_renv=Liste()
        while self.tete is not None :
            lst_renv.ajoute(self.tete.valeur)
            self.tete=self.tete.suivante
        return lst_renv




############   définition des fonctions    ###############








######### progamme principal #################

liste1=Liste()
liste1.ajoute("pomme")
liste1.ajoute("poire")
liste1.ajoute("coing")
liste1.ajoute("orange")

liste1.affiche1()


print()

"""
print("nbs d'éléments de la liste :",liste1.compter())

n=int(input("Quel est le rang choisi ?  "))
print("Elément du rang",n," de la liste :",liste1.nieme(n))
"""

liste_inversée=liste1.renverser()
print("Affichage de la liste inversée :")
liste_inversée.affiche1()