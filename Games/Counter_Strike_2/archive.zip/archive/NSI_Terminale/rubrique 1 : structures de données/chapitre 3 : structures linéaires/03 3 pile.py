﻿class Pile :
    def __init__ (self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def taille(self):
        return len(self.pile)

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

p=Pile()
print(p.estVide())
p.empiler(0)
p.empiler(10)
p.empiler(22)
print(p.sommet())
p.empiler(30)
p.empiler(44)
s1=p.sommet()
p.depiler()
p.depiler()
p.depiler()
print('La pile contient ',p.taille(),' élément(s)')
if p.estVide() :
    print('la pile est vide')
else :
    print("la pile n'est pas vide")
print(p)




