﻿class Pile :
    def __init__ (self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def taille(self):
        return len(self.pile)

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

def intervertir_tete(pile):
    var1=pile.depiler()
    var2=pile.depiler()
    pile.empiler(var1)
    pile.empiler(var2)
    return pile


def depile_3(pile):
    var1=pile.depiler()
    var2=pile.depiler()
    var3=pile.depiler()
    pile.empiler(var2)
    pile.empiler(var1)
    return pile

p=Pile()
p.empiler(0)
p.empiler(10)
p.empiler(22)
p.empiler(30)
p.empiler(44)

print(p)

intervertir_tete(p)

print(" Après la fonction intervertir_tete : ")
print(p)


depile_3(p)
print(" Après la fonction depile_3 : ")
print(p)


