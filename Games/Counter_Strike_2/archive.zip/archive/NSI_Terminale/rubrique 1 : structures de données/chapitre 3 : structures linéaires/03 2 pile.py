﻿class Pile :
    def __init__ (self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def taille(self):
        return len(self.pile)

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

p=Pile()
print(p.estVide())
p.empiler(0)
p.empiler(1)
p.empiler(2)
print(p.estVide())
print(p.taille())
s1=p.sommet()
p.empiler(3)
p.empiler(4)
s1=p.sommet()
p.depiler()
p.depiler()
p.depiler()
if p.estVide() :
    print('la pile est vide')
else :
    print("la pile n'est pas vide")
print(p)




