﻿############   définition des classes    ###############

class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Liste :
    """une liste chaînée"""

    def __init__(self):
        self.tete=None

    def est_vide(self) :
        return self.tete is None

    def ajoute(self,val) :
        self.tete=Cellule(val,self.tete)

    def affiche1(self):
        cel=self.tete
        while cel != None :
            print(cel.valeur," ",end="")
            cel=cel.suivante
        print()

    def compter(self) :
        if self.tete==None :
            return 0
        else :
            return 1+ Liste.longueur(self.tete.suivante)

    # méthode de classe utilisée pour la méthode compter(self) ci-dessus
    # ici on est obligé de créer une méthode de classe car le paramètre self
    # de compter est du type Liste alors que le paramètre cel de longueur
    # est du type Cellule

    def longueur(cel):
        if cel==None :
            return 0
        else :
            return 1 + Liste.longueur(cel.suivante)

    def nieme(self,n):
        if self.tete==None :
            raise IndexError("Il y a un problème avec la valeur n choisie")
        else :
            if n==1 :
                return self.tete  # ATTENTION A NE PAS RENVOYER LA VALEUR
            else :
                return Liste.nieme_recur(n-1,self.tete.suivante)


    # méthode de classe utilisée pour la méthode nieme(self) ci-dessus
    # pour les mêmes raisons que ci-dessus ici encore on est obligé de
    # créer une méthode de classe car le paramètre self de nieme
    # est du type Liste alors que le paramètre cel de nieme_recur
    # est du type Cellule

    def nieme_recur(n,cel):
        if cel==None :
            raise IndexError("Vous avez un problème avec l'indice n choisi")
        if n==1 :
            return cel    # ATTENTION A NE PAS RENVOYER LA VALEUR
        else :
            return Liste.nieme_recur(n-1,cel.suivante)


    def insere(self,valeur,n):
        # pour le cas où le rang dépasse la longueur de la liste
        if n>self.compter():
            dernier_rang=self.compter()
            next_cellule=Cellule(valeur,None)
            prev_cellule=Liste.nieme(self,dernier_rang)
            prev_cellule.suivante=next_cellule
        # pour le cas où on souhaite ajouter l'élément en tête de liste
        elif n==1 :
            self.ajoute(valeur)
        # pour les autres cas
        else :
            prev_cellule=Liste.nieme(self,n-1)
            #print("Valeur de la cellule d'avant :",prev_cellule.valeur)
            next_cellule=Liste.nieme(self,n)
            #print("Valeur de la cellule d'après :",next_cellule.valeur)
            new_cellule=Cellule(valeur,next_cellule)
            prev_cellule.suivante=new_cellule






############   définition des fonctions    ###############





##############################################
###       progamme principal          ########
##############################################

liste1=Liste()
liste1.ajoute("pomme")
liste1.ajoute("poire")
liste1.ajoute("coing")
liste1.ajoute("orange")

print("Affichage avant l'insertion :")
liste1.affiche1()

print()
print("nbs d'éléments de la liste initiale :",liste1.compter())
print()

liste1.insere("raisin",2)
print("Affichage après l'insertion :")
liste1.affiche1()
print("La liste contient désormais ", liste1.compter(), " éléments.")






