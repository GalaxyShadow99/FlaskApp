﻿class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class File2 :
    """ une file construite avec une liste chaînée"""

    def __init__(self):
        self.premier=None
        self.dernier=None

    def est_vide(self) :
        return self.premier is None

    def ajouter(self,val) :
        c=Cellule(val, None)
        if self.est_vide():
            self.premier=c
        else :
            self.dernier.suivante=c
        self.dernier=c

    def retirer(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        val=self.premier.valeur
        self.premier=self.premier.suivante
        if self.premier==None :
            self.dernier=None
        return val

    def compter(self):
        n=0
        c=self.premier
        while c is not None :
            n=n+1
            c=c.suivante
        return n

    def consulter_premier(self) :
        if self.est_vide():
            raise IndexError("Dépiler sur une pile vide !!!")
        return self.premier.valeur

    def vider(self) :
        self.premier=None
        self.dernier=None

    def __str__(self):
        retour =""
        if self.premier == None :
            return retour
        c=self.premier
        while not (c.suivante==None):
            e =c.valeur
            retour = retour + str(e) + ','
            c=c.suivante
        e=c.valeur
        retour=retour+str(e)
        return retour


f=File2()
f.ajouter(1)
f.ajouter(2)
f.ajouter(3)
f.ajouter(4)
f.ajouter(5)
f.ajouter(6)
#f.retirer()
f.retirer()

print("La file est la suivante :",f)

val = f.consulter_premier()
print("Le premier élément de la file a pour valeur : ",val)

nb=f.compter()
print("La file contient ",nb, " éléments ")



