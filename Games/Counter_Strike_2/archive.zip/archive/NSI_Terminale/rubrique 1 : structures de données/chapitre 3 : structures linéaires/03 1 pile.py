﻿class Pile:
    def __init__(self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

p = Pile()
p.empiler(0)
p.empiler(1)
p.empiler(2)
p.empiler(3)
p.empiler(4)
print(p)