﻿def vide():
    return None

# on aurait pu facilement se passe de la fonction cons() mais
# elle permet de mettre en valeur la notion de constructeur
def cons(x,L):
    return(x,L)

def ajouteEnTete(L,x):
    return cons(x,L)

def supprEnTete(L):
    return (L[0],L[1])

# la fonction estVide(L) retourne le booléen " L == None"
def estVide(L):
    return L == None

def compte(L):
    if estVide(L):
        return 0
    return 1 + compte(L[1])

L = vide()
print(estVide(L))

L = cons(15, cons(4, cons(3, cons(2, cons(1, cons(0,L))))))
print(estVide(L))
print(compte(L))

L = ajouteEnTete(L,20)
print(compte(L))

x, L=supprEnTete(L)
print(x)
print(compte(L))

x, L=supprEnTete(L)
print(x)
print(compte(L))





