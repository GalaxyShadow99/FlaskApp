# Créé par laure, le 11/10/2023 en Python 3.7

# encapsulation d'une liste dans un objet à l'aide d'un tableau dynamique

class Liste_tab:

    def __init__(self):
        self.liste = []

    def est_vide (self):
        long=len(self.liste)
        if long==0 : return True
        else : return False

    def ajouter_tete(self,val):
        self.liste.append(val)

    def __str__ (self):
        long=len(self.liste)
        if long==0 :
            return "La liste est vide"
        else :
            var="["
            for i in range (long-1):
                var = var + str(self.liste[i]) + ","
            var = var + str(self.liste[long-1]) + "]"
            return var

    def affiche_tete_liste (self):

        if self.est_vide() :
            print("La liste est vide")

        else :
            long=len(self.liste)
            print("Affichage de la liste en partant de la tête : ",end="")
            for i in range (long-1,0,-1):
                print(str(self.liste[i]),end="")
                print(" ",end="")
            print(str(self.liste[0]))


### programme principal ###
liste_1=Liste_tab()
print(liste_1.est_vide())
liste_1.affiche_tete_liste()
liste_1.ajouter_tete(3)
print(liste_1.est_vide())
liste_1.ajouter_tete(4)
liste_1.ajouter_tete(5)
liste_1.affiche_tete_liste()
