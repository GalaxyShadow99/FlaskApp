﻿############   définition des classes    ###############

class Cellule :
    """ une cellule d'une liste chaînée"""
    def __init__(self,v,s):
        self.valeur=v
        self.suivante=s

class Liste :
    """une liste chaînée"""

    def __init__(self):
        self.tete=None

    def est_vide(self) :
        return self.tete is None

    def ajoute(self,val) :
        self.tete=Cellule(val,self.tete)

    def compter(self) :
        if self.tete==None :
            return 0
        else :
            return 1+ Liste.longueur(self.tete.suivante)

    # méthode de classe utilisée pour la méthode compter(self) ci-dessus
    # ici on est obligé de créer une méthode de classe car le paramètre self
    # de compter est du type Liste alors que le paramètre cel de longueur
    # est du type Cellule

    def longueur(cel):
        if cel==None :
            return 0
        else :
            return 1 + Liste.longueur(cel.suivante)

    def nieme(self,n):
        if self.tete==None :
            raise IndexError("Il y a un problème avec la valeur n choisie")
        else :
            if n==1 :
                return self.tete.valeur
            else :
                return Liste.nième_recur(n-1,self.tete.suivante)


    # méthode de classe utilisée pour la méthode nieme(self) ci-dessus
    # pour les mêmes raisons que ci-dessus ici encore on est obligé de
    # créer une méthode de classe car le paramètre self de nieme
    # est du type Liste alors que le paramètre cel de nieme_recur
    # est du type Cellule

    def nième_recur(n,cel):
        if cel==None :
            raise IndexError("Vous avez un problème avec l'indice n choisi")
        if n==1 :
            return cel.valeur
        else :
            return Liste.nième_recur(n-1,cel.suivante)

    def affiche1(self):
        cel=self.tete
        while cel != None :
            print(cel.valeur," ",end="")
            cel=cel.suivante
        print()

    # ATTENTION la méthode affiche2 est à proscrire
    # car affiche2 vide la liste sur laquelle elle s'applique !!!!!!
    def affiche2(self):
        while self.tete != None :
            print(self.tete.valeur," ",end="")
            self.tete=self.tete.suivante


    def coupe(self):
        """ sépare une liste en deux listes ayant le même nombre d'éléments à un près """
        l1, l2 = Liste(), Liste()
        while not self.est_vide():
            l1.ajoute(self.tete.valeur)
            self.tete=self.tete.suivante
            if not self.est_vide():
                l2.ajoute(self.tete.valeur)
                self.tete=self.tete.suivante
        return l1,l2


############   définition des fonctions    ###############



def coupe(lst):
    """ sépare une liste en deux listes ayant le même
    nombre d'éléments à un près """
    l1, l2 = Liste(), Liste()
    while not lst.est_vide():
        l1.ajoute(lst.tete.valeur)
        lst.tete=lst.tete.suivante
        if not lst.est_vide():
            l2.ajoute(lst.tete.valeur)
            lst.tete=lst.tete.suivante
    return l1,l2




######### progamme principal #################

liste1=Liste()
liste1.ajoute("pomme")
liste1.ajoute("poire")
liste1.ajoute("coing")
liste1.ajoute("orange")

"""
liste1=Liste()
liste1.ajoute(4)
liste1.ajoute(3)
liste1.ajoute(2)
liste1.ajoute(1)
"""

liste1.affiche1()


print()
print("nbs d'éléments de la liste :",liste1.compter())

n=int(input("Quel est le rang choisi ?  "))
print("Elément du rang",n," de la liste :",liste1.nieme(n))

"""

liste1.affiche1()
print()
#L1,L2=coupe(liste1)
L1,L2=liste1.coupe()
print("la liste L1 :")
L1.affiche1()
print("la liste L2 :")
L2.affiche1()


"""
