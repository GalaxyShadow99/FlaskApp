﻿
def liste_n(n):
    if n==0 : return[]
    else :
        tab=[]
        for i in range(n,0,-1):
            tab.append(i)
        return tab


def affiche_liste_n(lst):
    n=len(lst)
    for i in range(n-1,-1,-1):
        print(lst[i],end=" ")
    print("\n")




t=liste_n(4)
print("Affichage du tableau qui implémente la liste.")
print('Dans ce cas, la tête de la liste apparaît " à la fin " du tableau')
print(t)
print()
print("Affichage de la liste avec la tête en premier :")
affiche_liste_n(t)
