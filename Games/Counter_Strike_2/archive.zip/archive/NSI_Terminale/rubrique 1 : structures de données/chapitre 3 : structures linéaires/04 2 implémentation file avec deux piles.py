﻿class Pile :
    def __init__ (self):
        self.pile=[]

    def empiler(self, e):
        self.pile.append(e)

    def sommet(self):
        return self.pile[-1]

    def depiler(self):
        s = self.pile.pop()
        return s

    def estVide(self):
        return len(self.pile) == 0

    def taille(self):
        return len(self.pile)

    def __str__(self):
        retour = ""
        for e in range(len(self.pile)-1, -1,-1):
            retour += str(self.pile[e]) + '\n'
        retour += "====\n"
        return retour

class File :
    def __init__ (self):
        self.pg=Pile()
        self.pd=Pile()

    def enfiler(self,element):
        self.pg.empiler(element)

    def defiler(self):
        if self.pd.estVide() :
            while not self.pg.estVide() :
                self.pd.empiler(self.pg.depiler())
        self.pd.depiler()

    def __str__(self):
        pg=self.pg.pile
        pd=self.pd.pile
        retour = ""
        for e in range(len(pd)-1, -1,-1):
            retour += str(pd[e]) + ','
        for e in pg :
            retour += str(e)+ ','
        return retour



f=File()
f.enfiler(0)
f.enfiler(1)
f.enfiler(2)
f.enfiler(3)
f.defiler()
f.defiler()
f.enfiler(4)
f.enfiler(5)
print(f)







