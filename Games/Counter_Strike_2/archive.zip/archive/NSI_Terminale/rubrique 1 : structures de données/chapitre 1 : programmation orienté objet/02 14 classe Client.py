# Créé par laure, le 05/09/2021 en Python 3.7


###########################################################
#######       définition des classes      #################
###########################################################

class Client:

    """ création d’une classe Client
    Le constructeur de la classe Client possède
    4 paramètres ( on dit aussi 4 arguments ) :
    self, nom , prenom et solde """

    def __init__(self, nom, prenom, solde):
        self.nom = nom
        self.prenom = prenom
        self.solde = solde

    def credit(self, nb):
        self.solde = self.solde + nb

    def debit(self, nb):
        self.solde = self.solde - nb

    def affichage(self) :
        print("Le client possède les attributs suivants:")
        print("Nom : ", self.nom)
        print("Prénom : ", self.prenom)
        print("Solde : ", str(self.solde))


###########################################################
#########            programme principal       ############
###########################################################

client1 = Client("Rostand", "Edmond", 10000 )
client1.credit(5000)
client1.affichage()
client2 = Client("Balzac", "Honoré", 1000 )
client2.debit(5000)
client2.affichage()

