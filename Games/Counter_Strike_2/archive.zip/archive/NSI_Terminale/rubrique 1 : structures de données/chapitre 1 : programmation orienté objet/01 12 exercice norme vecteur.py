﻿##########################################################
#########   importation des modules
##########################################################

from math import sqrt


##########################################################
###########    définition des fonctions
##########################################################

# question 3
def coord_vecteur(coordA,coordB):
    XAB=coordB[0]-coordA[0]
    YAB=coordB[1]-coordA[1]
    vecteurAB=(XAB,YAB)
    return vecteurAB


# question 4 et 5
def norme_vecteur(vecteur):
    norme=sqrt(vecteur[0]**2+vecteur[1]**2)
    return norme

##########################################################
###########    programme principal
##########################################################

#######      saisie des coordonnées des points    ########
#saisie des coordonnées du point A
XA,YA = -2,4
A=(XA,YA)

#saisie des coordonnées du point B
XB,YB = 3,3
B=(XB,YB)


#saisie des coordonnées du point C
XC,YC = 4,1
C=(XC,YC)

#saisie des coordonnées du point B
XD,YD = -3,-1
D=(XD,YD)

##   calcul des coordonnées et de la norme des vecteurs  ##
#coordonnées et norme du vecteur AB
AB=coord_vecteur(A,B)
print("coordonnées du vecteur AB : ",AB)
normeAB=norme_vecteur(AB)
print("norme du vecteur AB : ",normeAB)
print()

#coordonnées et norme du vecteur BC
BC=coord_vecteur(B,C)
print("coordonnées du vecteur BC : ",BC)
normeBC=norme_vecteur(BC)
print("norme du vecteur BC : ",normeBC)
print()

#coordonnées et norme du vecteur CD
CD=coord_vecteur(C,D)
print("coordonnées du vecteur CD : ",CD)
normeCD=norme_vecteur(CD)
print("norme du vecteur CD : ",normeCD)
print()

#coordonnées et norme du vecteur DA
DA=coord_vecteur(D,A)
print("coordonnées du vecteur DA : ",DA)
normeDA=norme_vecteur(DA)
print("norme du vecteur DA : ",normeDA)
print()

######    le triangle ABD est-il rectangle ?      #####
#le triangle ABD est rectangle si AB² + DA² = BD²
BD=coord_vecteur(B,D)
print("coordonnées du vecteur BD : ",BD)
normeBD=norme_vecteur(BD)
print("norme du vecteur BD : ",normeBD)
print()

#pour arrondir les nombres à 4 chiffres après la virgule
var1=round(normeAB**2+normeDA**2,4)
print("  AB² + DA²  =", var1)
var2=round(normeBD**2,4)
print("  BD²  =", var2)

if var1==var2 :
    print("Le triangle est rectangle")
else :
    print("Le triangle n'est pas rectangle")




