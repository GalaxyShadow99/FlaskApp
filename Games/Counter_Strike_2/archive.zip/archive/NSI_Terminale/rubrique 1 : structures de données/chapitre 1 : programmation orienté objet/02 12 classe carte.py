﻿##############################################################
#######          définition des classes            ###########
##############################################################

class Carte:

    """ constructeur de la classe """
    def __init__(self, val, coul):
        self.valeur = val
        self.couleur = coul


##############################################################
#######            programme principal             ###########
##############################################################

carte1 = Carte ("as","cœur")
carte2 = Carte ("10","carreau")
carte3 = Carte ("roi","pique")
carte4 = Carte("dame","trèfle")

print(carte1.valeur)
print(carte2.couleur)