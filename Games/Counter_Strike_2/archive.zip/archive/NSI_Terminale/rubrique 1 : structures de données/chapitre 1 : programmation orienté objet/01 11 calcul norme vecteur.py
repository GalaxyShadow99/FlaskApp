﻿##########################################################
#########   importation des modules
##########################################################

from math import sqrt


##########################################################
###########    définition des fonctions
##########################################################

# question 3
def coord_vecteur(coordA,coordB):
    XAB=coordB[0]-coordA[0]
    YAB=coordB[1]-coordA[1]
    vecteurAB=(XAB,YAB)
    return vecteurAB


# question 4 et 5
def norme_vecteur(vecteur):
    norme=sqrt(vecteur[0]**2+vecteur[1]**2)
    return norme

##########################################################
###########    programme principal
##########################################################

#saisie des coordonnées du point A
XA,YA = 1,1
A=(XA,YA)

#saisie des coordonnées du point B
XB,YB = 2,2
B=(XB,YB)

AB=coord_vecteur(A,B)
print("coordonnées du vecteur : ",AB)

norme=norme_vecteur(AB)
print("norme du vecteur : ",norme)

