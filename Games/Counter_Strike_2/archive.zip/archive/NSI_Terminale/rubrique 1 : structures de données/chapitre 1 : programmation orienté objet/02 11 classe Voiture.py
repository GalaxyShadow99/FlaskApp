# Créé par laure, le 05/09/2021 en Python 3.7


###########################################################
#######       définition des classes      #################
###########################################################

class Voiture:

    """ création d’une classe Voiture
    Le constructeur de la classe Voiture possède
     3 paramètres ( on dit aussi 3 arguments ) :
    self, marque et couleur """

    def __init__(self, marque, couleur):
        self.marq = marque
        self.coul = couleur


###########################################################
########   définition des fonctions   #####################
###########################################################

# version 1 :
def tri_voiture_1(parc,couleur_tri):
    nouveau_parc=[]
    for element in parc :
        if element.coul==couleur_tri :
            nouveau_parc.append(element)
    return nouveau_parc

# version 2 :
def tri_voiture_2(parc,couleur_tri):
    nouveau_parc=[]
    for i in range(len(parc)) :
        if parc[i].coul==couleur_tri :
            nouveau_parc.append(parc[i])
    return nouveau_parc

###########################################################
#########            programme principal       ############
###########################################################

v1 = Voiture("Peugeot", "rouge" )
v2 = Voiture("Peugeot","bleue")
v3 = Voiture("Citroën","jaune")
v4 = Voiture("Citroën","blanche")
v5 = Voiture("Renault","rouge")
v6 = Voiture("Renault","bleue")
v7 = Voiture("Renault","jaune")
v8 = Voiture("Renault","blanche")

parc1=[v1,v2,v3,v4,v5,v6,v7,v8]

parc2=tri_voiture_2(parc1,"rouge")
print("Le parc2 : \n")
for element in parc2 :
    print("marque : ",element.marq)
    print("couleur : ",element.coul)
    print()
