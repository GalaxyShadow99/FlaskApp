# Créé par laure, le 27/09/2021 en Python 3.7

class Intervalle :
    def __init__ ( self , debut , fin ) :
        """ premiere methode : constructeur """
        self.debut = debut # attribut
        self.fin = fin # attribut

    def get_debut(self):
        """ methode de recuperation d un attribut : accesseur """
        return( self.debut )

    def get_fin(self):
        """ methode de recuperation d un attribut : accesseur"""
        return( self.fin )

    def set_debut(self , nouveau_debut):
        """ methode de modification : mutateur """
        self.debut = nouveau_debut

    def set_fin(self , nouveau_fin):
        """ methode de modification : mutateur """
        self.fin = nouveau_fin

    def __str__(self):
        """ methode de présentation de l'objet """
        return "["+str(self.debut)+","+str(self.fin)+"]"


##############  programme principal    ##############

i1=Intervalle(3,7)
print(i1)

i1.set_fin(10)
print(i1)

print("début de l'intervalle ",i1, " : ",i1.get_debut())
print("fin de l'intervalle ",i1, " : ",i1.get_fin())















