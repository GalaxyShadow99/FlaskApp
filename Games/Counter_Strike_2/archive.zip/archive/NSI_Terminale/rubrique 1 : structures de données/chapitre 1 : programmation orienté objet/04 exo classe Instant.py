# Créé par laure, le 13/09/2021 en Python 3.7
#####     definition des classes    ##################"

class Temps:

    """ constructeur de la classe Temps.
    Un objet de la classe Temps possède un attribut : t"""
    def __init__(self, temps):
        self.t = temps

    @staticmethod
    # méthode statique qui permet de convertir en heure min
    # et seconde une durée exprimée en secondes
    def convertir(duree):
        a = duree//3600 # a est le nb d'heures
        b = duree % 3600 # nombre de secondes restant
        c = b //60 # c est le nb de minutes
        d = b % 60 # d est le nb de secondes
        return ( a, c , d )

    """ méthode qui permet d'afficher un objet de la
    classe Temps """
    def afficher(self):
        var_affiche=Temps.convertir(self.t)
        return str(var_affiche[0])+" heures "+str(var_affiche[1])+" minutes "+str(var_affiche[2])+" secondes"



#############     programme principal      ##############################

tps=Temps(7270)

print(tps.afficher())





