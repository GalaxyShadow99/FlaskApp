﻿
###########################################################
#######       définition des classes      #################
###########################################################

class Instant:

    """ constructeur de la classe """
    def __init__(self, h, m, s):
        self.h = h
        self.m = m
        self.s = s

    """ méthode pour afficher avec print une instance de la classe Instant """
    def __str__(self):
        return str(self.h)+ " h  "+str(self.m) + " min  "+str(self.s) + " sec  "

    """ méthode pour afficher une instance de la classe Instant """
    def affiche(self):

        min_plus = self.s//60
        self.s=self.s%60
        self.m=self.m+min_plus

        heure_plus = self.m//60
        self.m=self.m%60
        self.h=self.h+heure_plus

        return str(self.h)+ " h  "+str(self.m) + " min  "+str(self.s) + " sec  "

    """ méthode pour ajouter une durée à une instance de la classe Instant """
    def ajoute(self,a_h,a_m,a_s):

        self.s=self.s+a_s
        min_plus = self.s//60
        self.s=self.s%60

        self.m=self.m+min_plus+a_m
        heure_plus = self.m//60
        self.m=self.m%60

        self.h=self.h+heure_plus


###########################################################
#########            programme principal       ############
###########################################################

t=Instant(1,80,90)
print(t)
print(t.affiche())
t.ajoute(0,70,0)
print(t)