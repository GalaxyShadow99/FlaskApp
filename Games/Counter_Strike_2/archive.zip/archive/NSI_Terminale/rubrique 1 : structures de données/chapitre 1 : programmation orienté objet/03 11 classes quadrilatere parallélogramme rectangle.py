﻿from math import sqrt

class Point:
    """ constructeur de la classe Point
    Ce constructeur possède deux attributs : l'abscisse et l'ordonnée du point """
    def __init__(self, initX, initY):
        self.x = initX
        self.y = initY

    """ pour vérifier si l’abscisse du point est positive """
    def verif_x_positif(self):
       if self.x>0 : return True
       else : return False

    """ méthode pour afficher une instance de la classe Point """
    def __str__(self):
        return "(" + str(self.x) + "," + str(self.y) + ")"

class Quadrilatere:
    """ constructeur de la classe Quadrilatère.
    Ce constructeur possède quatre attributs : les quatre instances de la classe Point
    qui définiront les sommets du carré """
    def __init__(self, A, B, C, D):
        self.S1 = A
        self.S2 = B
        self.S3 = C
        self.S4 = D

    """ méthode qui permet de vérifier que les quatres points forment bien un parallélogramme
    Pour cela, on vérifie que le vecteur AB et égal au vecteur DC """
    def verif_parallelogramme(self):
        # calcul des coordonnées du vecteur AB
        xAB=self.S2.x - self.S1.x
        xAB=round(xAB,2)
        yAB=self.S2.y - self.S1.y
        yAB=round(yAB,2)
        # calcul des coordonnées du vecteur DC
        xDC=self.S3.x - self.S4.x
        xDC=round(xDC,2)
        yDC=self.S3.y - self.S4.y
        yDC=round(yDC,2)

        #print("(xAB,yAB) : (",xAB,",",yAB,")  et (xDC,yDC) : (",xDC,",",yDC  )

        if (xAB,yAB) == (xDC,yDC) :
            return Parallelogramme(self)
        else:
            return None

class Parallelogramme:
    """ constructeur de la classe Parallelogramme.
    Ce constructeur possède quatre attributs : les quatre instances de la classe Point
    qui définiront les sommets du parallélogramme """
    def __init__(self,quadri):
        self.quadri = quadri

    """ méthode qui permet vérifier que le parallélogramme est bien un rectangle
    Pour cela, on vérifie que le vecteur AB est perpendiculaire au vecteur BC"""
    def verif_rectangle(self):
        #vérification que le vecteur AB est perpendiculaire au vecteur BC
        # calcul des coordonnées du vecteur AB
        xAB=self.quadri.S2.x - self.quadri.S1.x
        xAB=round(xAB,2)
        yAB=self.quadri.S2.y - self.quadri.S1.y
        yAB=round(yAB,2)
        # calcul des coordonnées du vecteur BC
        xBC=self.quadri.S3.x - self.quadri.S2.x
        xBC=round(xBC,2)
        yBC=self.quadri.S3.y - self.quadri.S2.y
        yBC=round(yBC,2)

        var=round(xAB*xBC-yAB*yBC,2)

        if var==0 :
            return Rectangle(self)
        else:
            return None

    def affiche(self):
        print("Les 4 sommets forment bien un parallélogramme")


class Rectangle:
    """ constructeur de la classe Parallelogramme.
    Ce constructeur possède quatre attributs : les quatre instances de la classe Point
    qui définiront les sommets du parallélogramme """
    def __init__(self, para):
        self.para=para

    def affiche(self):
        print("Les 4 sommets forment bien un rectangle")




class Carre:
    """
    méthode qui permet vérifier que les quatres points forment bien un carré
    Pour cela, on vérifie que le vecteur AB et égal au vecteur DC et que
    l'abscisse de A est égal à l'abscisse de D
    def verif_carre(self):
    """
    pass

#########################################################################
#############           programme principal               ###############
#########################################################################

p1 = Point(1,2)
p2 = Point(2,4)
p3 = Point(4,4)
p4 = Point(3,1)

# création d'une instance de la classe Quadrilatere
quadri=Quadrilatere(p1,p2,p3,p4)

# création d'une instance de la classe Parallelogramme
para=quadri.verif_parallelogramme()

if para==None :
    pass
else:
    para.affiche()
    # création d'une instance de la classe Rectangle
    rect=para.verif_rectangle()

    if rect==None :
        pass
    else:
        rect.affiche()







