# Créé par laure, le 05/09/2021 en Python 3.7

###########################################################
#######       définition des classes      #################
###########################################################


class Voiture:

    """ création d’une classe Voiture"""
    """ cette classe Voiture possèdera 5 attributs"""

    """Le constructeur de la classe Voiture possède
    6 paramètres ( on dit aussi 6 arguments ) :
    self, marque, couleur et compteur """

    def __init__(self, marque, couleur, compteur,consommation,prix_litre):
        self.marq = marque
        self.coul = couleur
        self.compt = compteur
        self.conso = consommation
        self.prix_par_L = prix_litre

    """ méthode ajouter """
    def ajouter_km(self,km) :
        self.compt=self.compt+km
        nb_L=self.conso*km/100
        print("La voiture a consommé ",nb_L," pour parcourir les ",km,"km")
        prix_L=nb_L*self.prix_par_L
        print("Pour parcourir ces ",km,"km, le coût du carburant est  ",prix_L,".")

    """ méthode affichage """
    def affichage(self) :
        print("La voiture possède les attributs suivants:")
        print("La marque : ", self.marq)
        print("La couleur : ", self.coul)
        print("km au compteur : ", str(self.compt))



###########################################################
#########            programme principal       ############
###########################################################


v1 = Voiture("Peugeot", "rouge",1000,5,4 )


print("km début location : ",v1.compt)
v1.ajouter_km(200)
v1.affichage()


