def fonction_1(n):
    if n == 3 :
        return 0
    else :
        return 10 + fonction_1(n-1)

print( fonction_1 (5))



def fonction_2(n):
    if n == 2 :
        return 0
    else :
        return 10 + fonction_2(n-2)

print( fonction_2 (6))


def fonction_3(n):
    if n == 0 :
        return 10
    elif n % 2 == 0 :
        return fonction_3(n-2)
    else :
        return 10 + fonction_3(n-1)

print( fonction_3 (5))
