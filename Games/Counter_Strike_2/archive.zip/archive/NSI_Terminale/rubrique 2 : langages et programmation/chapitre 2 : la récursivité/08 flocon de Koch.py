﻿from turtle import *

"""
il y a un problème avec la fenêtre ouverte avec turtle,
pour que cela ne pose pas de soucis et qu'elle reste ouverte
après l'exécution du dessin, il faut terminer avec
la fonction done()
"""

def koch(n,l):

    if n==0:
        forward(l)

    else :
        koch(n-1,l/3)
        left(60)
        koch(n-1,l/3)
        right(120)
        koch(n-1,l/3)
        left(60)
        koch(n-1,l/3)

def flocon_koch(etape,longueur):
    """Fonction pour dessiner un flocon de Von Koch
    depuis le coin haut gauche"""
    up()
    goto(-100,100)
    down()
    for i in range(3):  #Pour chaque côté du triangle initial
        koch(etape,longueur)  #Courbe de Von Koch
        right(120)


flocon_koch(3,300)
done()




