'use strict';
var dark_layout = 'false';
var rtl_layout = 'false';
var preset_color = 'preset-1';
var box_container = 'false';
var font_name = 'Roboto';
