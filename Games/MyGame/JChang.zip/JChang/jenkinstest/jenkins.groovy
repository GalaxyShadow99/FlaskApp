job {
    name "jeremy-build"
    steps {
        shell 'echo STARTING_BUILD'
        shell 'sleep 30'
        shell 'echo END_BUILD'
    }
}
